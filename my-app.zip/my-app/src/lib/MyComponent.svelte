<script lang="en">

    let { name = 'Samiha'} = $props(); 

</script>

<p>{name}</p>